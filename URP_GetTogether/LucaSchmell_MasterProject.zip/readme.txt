OUTER SPACE - README - GUIDE TO PLAY

Navigate into the folder "Build"
Start the application "URP_GetTogether.exe"

The game can only be played with two players!

One player needs to host the game (PLAY => Host Game) and the second player needs to join the hosted session (PLAY => Join Game).
Right below the Join Game button, is a textfield where the client needs to enter the hosts IP address.
Per default this IP adress is set to 127.0.0.1. This address can be used to play the game on a single computer.
Simply open up the game two times. Host the game in one instance and join the game on the other instance.
Do not press "Start Game" until the second player joined in.

When playing within one network (LAN) this IP address needs to be the local IP address of the hosts computer.
This IP can be found via cmd console (search for "cmd" in the Windows searchbar). 
Enter "ipconfig" inside cmd and locate the the "Ipv4 Address".
It always looks like this: 192.168.X.X
The last digits differ with each device inside the network.

When playing over the internet (WAN), the needed IP address can be seen via websites like:
https://www.wieistmeineip.de/
You will need the Ipv4 address.
Additionally, in the settings of your routher, you need to forward the two ports: 1337, 7777 (for UDP + TCP protocol).
The following guide can be used: https://www.noip.com/support/knowledgebase/general-port-forwarding-guide/

Also, create a firewall exception for the game application or disable the firewall while playing.

Once this is done, the player can join. 
The host should see UI elements saying "Player 1" and "Player 2".
If the second player correctly joins the hosted game, the text beneath "Player 2" should change show the second users IP address.
As long as the UI displays "Not connected", the second player did not join correctly!

If the menu gets stuck or shows multiple overlapping UI elements, restart the application.

Make sure both internet connections are stable! If a player disconnects, you need to start over.


Controls:
Movement - W/A/S/D
Sprint - Shift
Jump - Spacebar
Crouch - CTRL
Interact - E
Change to First/Third Person - V
Mute Music - M

For debugging:
If a battery disappears, press F2 to spawn a substitute battery.
If you are stuck within the "carry" animation, press the letter O to reset your animation. 
O also drops the currently held item. Only used for testing purposes.

For testing functionality:
The game can be also be tested for functionality with a single player. 
Just host the game (PLAY => Host Game).
Press P once your character gets spawned. This enables teleporters at the back of each room.
This way it is possible to travel back and forth from core room to the bridge.
NOTE: THIS IS NOT OBVIOUSLY THE INTENDED WAY TO PLAY THE GAME! 

